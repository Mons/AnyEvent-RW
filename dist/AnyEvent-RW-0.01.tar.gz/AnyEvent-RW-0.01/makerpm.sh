rm ~/rpm/RPMS/noarch/perl-AnyEvent-RW-0.01-1.noarch.rpm
cpan2rpm --no-sign --requires="perl-AnyEvent" --no-requires="perl(AnyEvent::RW::Kit)" dist/AnyEvent-RW-0.01.tar.gz
